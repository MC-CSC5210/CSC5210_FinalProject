/* 
 * File:   GLFWApplication.h
 * Author: stuetzlec
 * Modified by: John Wyeth, Thomas Kelley, and Pat Langille
 * 
 * Created on October 10, 2017, 3:31 PM
 */

#ifndef SFMLAPPLICATION_H
#define SFMLAPPLICATION_H

#include <GL/glew.h>
#include <SFML/Graphics.hpp>
#include <SFML/OpenGL.hpp>
#include <glm/glm.hpp>
#include <vector>
#include "Shader.hpp"
#include "Camera.h"
#include <stdlib.h>     
#include <time.h>      
#include "DrawableObject.h"
#include "AmbientLight.hpp"

using glm::vec3;
using glm::vec2;
using glm::mat4;
using std::vector;

class SFMLApplication {
public:
    SFMLApplication();
    SFMLApplication(const SFMLApplication& orig);
    virtual ~SFMLApplication();

    // General Initialization Function
    int initializeApplication(int, int, int, string, int, int);
    void initiateDrawLoop();

    // Add a drawable object to the list
    void addDrawableObject(DrawableObject*);
    void addLight(Light*);
    void setShaderProgram(Shader*); // Set the current shader program
    DrawableObject* select();
    // Set the function to handle the events
    void setCallback( void (*func)(sf::Window&)) {
        eventFunc = func;
    }
     
    // Set the camera and the shader
    void setCamera(Camera* c) { camera = c; }
    void setShader(Shader* s1) { shader1 = s1;}
    int getReverse();
    void clearDrawables();
    void clearLights();
private:
    vector< DrawableObject* > drawables; // The list of everything to draw
    vector< Light* > lights;
    Shader* shader1; // The current shader program
    
    Camera* camera;
    sf::Window* window; // The OpenGL context window
    sf::Clock clock;    // The clock object
    sf::Time curTime; // The current time in the system
    int count;
    int reverse;
    
    void draw(); // Draw all of the drawable objects

    // Callback functions using some function pointers
    void (*eventFunc)(sf::Window&);
    
};

#endif /* GLFWAPPLICATION_H */

