/* 
 * File:   DirectionalLight.cpp
 * Author: m228student
 * 
 * Created on November 20, 2017, 4:27 PM
 */

#include "DirectionalLight.h"

DirectionalLight::DirectionalLight(vec3 col, vec3 dir, GLfloat st, GLfloat sh) : Light(col) {
    direction = glm::normalize(dir);
    strength = st;
    shininess = sh;
    
}

void DirectionalLight::connectLightToShader(Shader* s) {
    GLint dirLightid = s->GetVariable("directLightColor");
    GLint shininessid = s->GetVariable("Shininess");
    GLint strengthid = s->GetVariable("Strength");
    GLint dirLightWeight = s->GetVariable("directionalWeight");
    GLint lightDirid = s->GetVariable("LightDirection");

    s->SetVector3(dirLightid, 1, &color[0]);
    s->SetVector3(lightDirid, 1, &direction[0]);
    s->SetFloat(shininessid, shininess);
    s->SetFloat(strengthid, strength);
    if (isEnabled()) {
        s->SetFloat(dirLightWeight, 1.0);
    } else {
        s->SetFloat(dirLightWeight, 0.0);
    }
}