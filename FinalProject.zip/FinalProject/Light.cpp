/**
 * File:    Light.cpp
 * Author:  John Wyeth, Thomas Kelley
 */

#include "Light.hpp"

Light::Light( vec3 col ){
    enabled = true;
    color = col;
}