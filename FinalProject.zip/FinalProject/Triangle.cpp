/**
 * Code written by Christopher Stuetzle
 * Modified by Pat Langille
 */
#include "Triangle.hpp"
#include "Camera.h"

Triangle::Triangle(vec3 _a, vec3 _b, vec3 _c, GLfloat tCoords[])
{
    a = _a;
    b = _b;
    c = _c;

    GLfloat verts[] = {a.x, a.y, a.z,
        b.x, b.y, b.z,
        c.x, c.y, c.z};
    
    GLfloat texs[6];
    for(int i = 0; i < 6; i++){
        texs[i] = tCoords[i];
    }
    
    // Set up the VBO
    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);
    glBindVertexArray(VAO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);

    // Populate with the data
    glBufferData(GL_ARRAY_BUFFER, sizeof (verts) + sizeof (texs), NULL, GL_STATIC_DRAW);
    glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof (verts), verts);
    glBufferSubData(GL_ARRAY_BUFFER, sizeof (verts), sizeof (texs), texs);

    // Set up the attribute array with two attributes
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, 0);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 0, (void*) sizeof (verts));
    glEnableVertexAttribArray(0);
    glEnableVertexAttribArray(1);

}

// The draw function
void Triangle::draw(Shader* s, Texture* tex)
{
    glBindVertexArray(VAO);
    s->useProgram();

    glBindTexture(GL_TEXTURE_2D, tex->getTexID());
    // Draw
    glDrawArrays(GL_TRIANGLES, 0, 3);

    glBindVertexArray(0);

}

float Triangle::getZ(){
    return a.z;
}