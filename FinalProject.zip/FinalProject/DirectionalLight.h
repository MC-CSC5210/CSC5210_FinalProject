/* 
 * File:   DirectionalLight.h
 * Author: John Wyeth
 *
 * Created on November 20, 2017, 4:27 PM
 */

#ifndef DIRECTIONALLIGHT_H
#define DIRECTIONALLIGHT_H
#include "Light.hpp"
#include "glm/glm.hpp"

using glm::vec3;

class DirectionalLight : public Light {
public:
    DirectionalLight(vec3 col, vec3 dir, GLfloat st, GLfloat sh);
    void connectLightToShader(Shader*);
private:
    vec3 direction;
    GLfloat shininess;
    GLfloat strength;
};

#endif /* DIRECTIONALLIGHT_H */
