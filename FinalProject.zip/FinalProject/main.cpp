/**
 * Created by Christopher Stuetzle (2017)
 * Modified by: John Wyeth, Thomas Kelley, Pat Langille 
 */

#include <iostream>
#include <cstdio>

// User Includes
#include "SFMLApplication.h"
#include "Shader.hpp"
#include "Prism.h"
#include "Camera.h"
#include "glm/glm.hpp"
#include "AmbientLight.hpp"
#include "DirectionalLight.h"
#include "Rectangle.h"

using namespace std;

// Window information
GLuint winHeight = 1080;
GLuint winWidth = 1920;

int reversed = 0;
int count = 0;
int light = 1;
int jump = 0;
int run = 0;
// The current mouse position
double deltaX, deltaY;
bool lButtonDown;
bool rButtonDown;
vec2 mousePos;

// The one tetrahedron
vector<DrawableObject*> objects;
vector<DrawableObject*> store;
DrawableObject* selected;
Shader* s_1;
Shader* s_2;
Camera* c;
Texture* t;
Light* ambient;
Light* direct;
Prism* p;
Prism* light1;
Prism* light2;
Rectangle* temp;
Texture* pa;
int play = 0;

SFMLApplication app;


// Init function to set up the geometry
// Pre: None
// Post: The quads are set up

void init() {

    //creates the land around the water
    t = new Texture("grass.png");
    p = new Prism(vec3(-3000, -10, -1000), vec3(3000, -10, -1000), vec3(-3000, -10, 3000), t, 8);
    app.addDrawableObject(p);
    
    //creates the water
    t = new Texture("water.png");
    p = new Prism(vec3(-1000, -2.1, -800), vec3(1000, -2.1, -800), vec3(-1000, -2.1, 500), t, 2.1);
    app.addDrawableObject(p);
    
    //creates the cliff
    t = new Texture("rock.png");
    p = new Prism(vec3(-50, -10, 450), vec3(50, -10, 450), vec3(-50, -10, 500), t, 510);
    app.addDrawableObject(p);
    
    t = new Texture("redlight.png");
    light1 = new Prism(vec3(-45, 500, 455), vec3(-43, 500, 455), vec3(-45, 500, 460), t, 2);
    app.addDrawableObject(light1);
    
    light2 = new Prism(vec3(45, 500, 455), vec3(43, 500, 455), vec3(45, 500, 460), t, 2);
    app.addDrawableObject(light2);
    
    pa = new Texture("playagain.png");
    
    // Set up the shader
    string shaders1[] = {"Texture.vert", "Texture.frag"};
    s_1 = new Shader(shaders1, true);
    
    // Set up the camera
    vec3 pos(0, 510, 495);
    GLfloat FOV = 45.0f;
    GLfloat nearPlane = 0.1f;
    GLfloat farPlane = 2000.0f;
    c = new Camera(pos, winWidth, winHeight);
    c -> setPerspective(FOV, (GLfloat) winWidth / (GLfloat) winHeight,
            nearPlane, farPlane);
    app.clearLights();
    ambient = new AmbientLight(vec3(0.15, 0.15, 0.15));
    direct = new DirectionalLight(vec3(0.4),
           glm::normalize(vec3(-0.5, 0.5, 0.5)), 0.8, 0.51);
    ambient->setColor(vec3(0.15, 0.15, 0.15));
    app.addLight(ambient);
    app.addLight(direct);

}

void handleEvents(sf::Window& window) {
    sf::Event event;
    float pow = 0.5;
    // While there are still events.
    while (window.pollEvent(event)) {
        if (event.type == sf::Event::Closed) {
            window.close();
        }
        else if (event.type == sf::Event::Resized) {
            winHeight = event.size.height;
            winWidth = event.size.width;
            glViewport(0, 0, winWidth, winHeight);
        }// Keyboard pressed
        else if(event.type == sf::Event::KeyPressed){
             if(event.key.code == sf::Keyboard::W){
                if((c->getPosition().x + c->getViewVector().x) > -50 && (c->getPosition().x + c->getViewVector().x) < 50 &&
                       (c->getPosition().z +c->getViewVector().z) > 450 && (c->getPosition().z +c->getViewVector().z) < 500)
                {
                    c->setPosition(c->getPosition().x+c->getViewVector().x, c->getPosition().y, c->getPosition().z +c->getViewVector().z);
                }
            }
            else if(event.key.code == sf::Keyboard::A){
                if((c->getPosition().x - c->getRightVector().x) > -50 && (c->getPosition().x - c->getRightVector().x) < 50 &&
                       (c->getPosition().z - c->getRightVector().z) > 450 && (c->getPosition().z - c->getRightVector().z) < 500)
                {
                    c->setPosition(c->getPosition().x - c->getRightVector().x, c->getPosition().y, c->getPosition().z - c->getRightVector().z);
                }
            }
            else if(event.key.code == sf::Keyboard::S){
                if((c->getPosition().x - c->getViewVector().x) > -50 && (c->getPosition().x - c->getViewVector().x) < 50
                        && (c->getPosition().z - c->getViewVector().z) > 450 && (c->getPosition().z - c->getViewVector().z) < 500)
                {
                    c->setPosition(c->getPosition().x - c->getViewVector().x, c->getPosition().y, c->getPosition().z - c->getViewVector().z);
                }
            }
            else if(event.key.code == sf::Keyboard::D){
                if((c->getPosition().x + c->getRightVector().x) > -50 && (c->getPosition().x + c->getRightVector().x) < 50 &&
                       (c->getPosition().z +c->getRightVector().z) > 450 && (c->getPosition().z +c->getRightVector().z) < 500)
                {
                    c->setPosition(c->getPosition().x+c->getRightVector().x, c->getPosition().y, c->getPosition().z + c->getRightVector().z);
                }
            }
            else if(event.key.code == sf::Keyboard::U){
                if(c->getPosition().y - pow > 510 && ((c->getPosition().x + c->getRightVector().x) > -50 && (c->getPosition().x + c->getRightVector().x) < 50 &&
                       (c->getPosition().z +c->getRightVector().z) > 450 && (c->getPosition().z +c->getRightVector().z) < 500)){
                    c->setPosition(c->getPosition().x, c->getPosition().y - pow, c->getPosition().z);
                }
            }
            else if(event.key.code == sf::Keyboard::M){
                if(c->getPosition().y < 0.5 && jump == 0){
                    c->setPosition(vec3(0, 510, 495));
                    app.clearPlayAgain();
                }
            }
            else if(event.key.code == sf::Keyboard::R){
                if(jump == 1){
                    //rotate camera backwards
                    c->setViewByMouse(0, 30);
                }
            }
            else if(event.key.code == sf::Keyboard::F){
                if(jump == 1){
                    //rotate camera forward
                    c->setViewByMouse(0, -30);
                }
            }
        }
        else if (event.type == sf::Event::KeyReleased) {
            if (event.key.code == sf::Keyboard::Q) {
                window.close();
            }
            else if (event.key.code == sf::Keyboard::L){
                if(light == 1){
                    direct->setColor(vec3(0.75, 0.75, 0.75));
                    light = 0;
                     
                }
                else{
                    direct->setColor(vec3(0.15, 0.15, 0.15));
                    light = 1;
                }
                app.clearLights();
                app.addLight(direct);
            }
            else if(event.key.code == sf::Keyboard::Space){
                if(c->getPosition().z > 450 && c->getPosition().z < 460){
                    if(run == 1){
                    //jump
                    c->setPosition(c->getPosition().x, c->getPosition().y + 5, c->getPosition().z - 15);
                    jump = 1;
                    t = new Texture("redlight.png");
                    light1->setTexture(t);
                    light2->setTexture(t);
                    }
                }
            }
            else if(event.key.code == sf::Keyboard::J){
                //initiate run
                run = 1;
                t = new Texture("greenlight.png");
                light1->setTexture(t);
                light2->setTexture(t);
            }
        }            // Mouse button pressed  
        else if (event.type == sf::Event::MouseButtonReleased) {
            if (event.mouseButton.button == sf::Mouse::Left) {
                lButtonDown = false;
            } else if (event.mouseButton.button == sf::Mouse::Right) {
                rButtonDown = false;
            }
        } else if (event.type == sf::Event::MouseButtonPressed) {
            if (event.mouseButton.button == sf::Mouse::Left) {
                lButtonDown = true;
            } else if (event.mouseButton.button == sf::Mouse::Right) {
               rButtonDown = true;
            }
        } else if (event.type == sf::Event::MouseMoved) {
            sf::Vector2i m = sf::Mouse::getPosition();
            deltaX = mousePos.x - m.x;
            deltaY = mousePos.y - m.y;
            mousePos.x = m.x;
            mousePos.y = m.y;
            
            // If the associated button is down, make sure to 
            //   update the camera accordingly.
            if (lButtonDown) {
                c -> setViewByMouse(deltaX, deltaY);
            }
            if (rButtonDown) {
                // This is negative BECAUSE THE LOOK VECTOR IS BACKWARDS...hack
                //c -> moveCamera(-deltaX, deltaY, 26);
            }
        }
      
    }
    if(run == 1){
        if((c->getPosition().x + c->getViewVector().x) > -50 && (c->getPosition().x + c->getViewVector().x) < 50 &&
                       (c->getPosition().z +c->getViewVector().z) > 450 && (c->getPosition().z +c->getViewVector().z) < 500)
                {
                    c->setPosition(c->getPosition().x+c->getViewVector().x, c->getPosition().y, c->getPosition().z +c->getViewVector().z);
                }
        else{
            run = 0;
        }
    }
    //gravity
        if(jump == 1){
            c->setPosition(c->getPosition().x, c->getPosition().y - 2.5, c->getPosition().z - 0.2);
        }
        if(c->getPosition().y < -0.5){
            jump = 0;
            app.clearPlayAgain();
            temp = new Rectangle(vec3(((c->getPosition().x) - 2.5), -3.5, (c->getPosition().z) - 5),
                        vec3(((c->getPosition().x) + 2.5), -3.5, (c->getPosition().z) - 5),
                        vec3(((c->getPosition().x) - 2.5), -4.5, (c->getPosition().z) - 5),
                        vec3(((c->getPosition().x) + 2.5), -4.5, (c->getPosition().z) - 5),
                    pa);
            app.addDrawableObject(temp);
        }
}

int main() {
    // Set up the GLFW application
    app.initializeApplication(8, 3, 3,
            "Cliff Jump", winWidth, winHeight);

    // Assign your callback functions (the ones you write) to the internal
    // callbacks of the application class.
    app.setCallback(handleEvents);

    // Initialize stuff local to the program
    init();
    app.setShader(s_1);
    app.setCamera(c);

    // Tell the application to "go"
    app.initiateDrawLoop();



    return 0;
}
